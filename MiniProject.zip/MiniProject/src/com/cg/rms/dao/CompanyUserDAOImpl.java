package com.cg.rms.dao;

import java.sql.*;
import java.util.ArrayList;

import com.cg.rms.beans.Candidate;
import com.cg.rms.beans.CandidatePersonal;
import com.cg.rms.beans.Company;
import com.cg.rms.beans.CompanyMaster;
import com.cg.rms.beans.JobRequirements;
import com.cg.rms.exception.RecruitmentException;
import com.cg.rms.util.DBUtil;

public class CompanyUserDAOImpl implements CompanyUserDAO {
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	@Override
	public int registerCompany(CompanyMaster companyMaster)
			throws RecruitmentException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int postJobRequirement(JobRequirements jobRequirement)
			throws RecruitmentException {
		
		return 0;
	}

	@Override
	public ArrayList<Company> getCompanyDetails() throws RecruitmentException {
		ArrayList<Company> companyList=new ArrayList<Company>();
		Company company=new Company();
		try
		{
			con=DBUtil.getConn();
			String selectqry1="SELECT *FROM CANDIDATE_PERSONAL WHERE  candidate_id= candidateId";
			st=con.createStatement();
			rs=st.executeQuery(selectqry1);
			while(rs.next())
			{
				candidate.setCandidatePersonal(new CandidatePersonal(rs.getString(1),rs.getString(2),
						rs.getString(3),rs.getDate(4),
						rs.getString(5),rs.getString(6),rs.getString(7),
						rs.getString(8),rs.getString(9)));
				candidateList.add(candidate);
						
			}
		return null;
	}

	
	
	

}
