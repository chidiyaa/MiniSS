package com.cg.rms.service;

import java.util.ArrayList;

import com.cg.rms.beans.JobRequirements;
import com.cg.rms.dao.CandidateDAOImpl;
import com.cg.rms.exception.RecruitmentException;

public class CandidateServiceImpl implements CandidateService {
	
	CandidateDAOImpl cdao=new CandidateDAOImpl();
	@Override
	public ArrayList<JobRequirements> search(String qualification,
			String position, int experience,String location) throws RecruitmentException {
		
            ArrayList<JobRequirements> jobReq=cdao.getJobRequirements();
            ArrayList<JobRequirements> jobReq1=new ArrayList<JobRequirements>();
            for(JobRequirements job:jobReq)
            {
            	String qual=job.getQualificationRequired();
                Integer exp=job.getExperienceRequired();
                String loc=job.getJobLocation();
                String pos=job.getPositionRequired();
                if(pos.equalsIgnoreCase(position) && loc.equalsIgnoreCase(location) && exp==experience && qual.contains(qualification)){
                    jobReq1.add(job);
                    
                }
                
            }
            return jobReq1;
            
       
	}
	public static void main(String args[])
	{
			CandidateServiceImpl csim=new CandidateServiceImpl();
			try {
				System.out.println(csim.search("B.tech","Developer",1,"Hyd"));
			} catch (RecruitmentException e) {
				
				e.printStackTrace();
			}
	}

}
