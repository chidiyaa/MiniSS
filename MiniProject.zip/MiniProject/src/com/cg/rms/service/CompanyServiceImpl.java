package com.cg.rms.service;

import java.time.LocalDate;

import java.util.ArrayList;

import com.cg.rms.beans.CandidatePersonal;
import com.cg.rms.beans.CandidateQualifications;
import com.cg.rms.beans.CandidateWorkHistory;

public class CompanyServiceImpl implements CompanyService {

	@Override
	public ArrayList<CandidatePersonal> SearchByCompany(String position,
			String experience, String qualification) {
		
		 ArrayList<CandidateWorkHistory> jobReq=new ArrayList<CandidateWorkHistory>();
         ArrayList<CandidateQualifications> jobReq1=new ArrayList<CandidateQualifications>();
         ArrayList<CandidatePersonal> jobReq2=new ArrayList<CandidatePersonal>();
         ArrayList<CandidatePersonal> jobReq3=new ArrayList<CandidatePersonal>();
         for(CandidateWorkHistory job1:jobReq)
         {
             LocalDate dur1=job1.getEmploymentFrom();
             LocalDate dur2=job1.getEmploymentTo();
             
             Integer workExp1=dur2.getYear()-dur1.getYear();
             String workExp=workExp1.toString();
             
             if(dur2.getMonthValue()<dur1.getMonthValue())
             {
                 workExp1=dur2.getYear()-dur1.getYear()-1;
             }
             else
                 workExp1=dur2.getYear()-dur1.getYear();
             
             String pos=job1.getPositionHeld();
             
             for(CandidateQualifications job2:jobReq1)
             {
                 for(CandidatePersonal job:jobReq2)
                 {
                     String qual=job2.getQualificationName();
                     if(pos.equals(position) && qual.contains(qualification)  && workExp.equals(experience) &&(job1.getCandidateId().equals(job2.getCandidateId())) && (job2.getCandidateId().equals(job.getCandidateId()) ))
                     {
                          jobReq3.add(job);
                     }
                 }
             }
             
             
         }
         return jobReq3;
         
     }

	}
	
