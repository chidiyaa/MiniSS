package com.cg.rms.service;

import java.util.ArrayList;

import com.cg.rms.beans.JobRequirements;
import com.cg.rms.exception.RecruitmentException;

public interface CandidateService {
		ArrayList<JobRequirements> search(String qualification,String position,int experience,String location) throws RecruitmentException;
}
