package com.cg.rms.service;

import java.util.ArrayList;

import com.cg.rms.beans.CompanyMaster;
import com.cg.rms.beans.PlacedCandidate;
import com.cg.rms.dao.PlacedCandidateDAO;
import com.cg.rms.dao.PlacedCandidateImpl;
import com.cg.rms.exception.RecruitmentException;

public class PlacedCandidateServiceImpl implements PlacedCandidateService {

	PlacedCandidateImpl pcdao=new PlacedCandidateImpl();
	@Override
	public int pCountMonth(String month) throws RecruitmentException {
		ArrayList<PlacedCandidate> pmon=pcdao.searchPlaced();
		int count=0;
		
		for(PlacedCandidate pc:pmon)
		{
			if(month.equalsIgnoreCase(pc.getMonth()))
				count++;
			
		}
		return count;
	}

	@Override
	public int pCountCompany(String Company) throws RecruitmentException {
		ArrayList<PlacedCandidate> pcom=pcdao.searchPlaced();
		int count=0;
		CompanyMaster cm=new CompanyMaster();
		
		for(PlacedCandidate pc:pcom)
		{
			if(cm.getCompanyId().equals(pc.getCompanyId()))
					{		
						if(cm.getCompanyName().equals(Company))
							count++;
					}
					
			
		}
		return count;
	}

	@Override
	public int pCountDesignation(String designation)
			throws RecruitmentException {
		ArrayList<PlacedCandidate> pdes=pcdao.searchPlaced();
		int count=0;
		
		for(PlacedCandidate pc:pdes)
		{
			if(designation.equalsIgnoreCase(pc.getDesignation()))
				count++;
			
		}
		return count;
		
	}
	public static void main(String args[])
	{
		PlacedCandidateServiceImpl pcsi=new PlacedCandidateServiceImpl();
		try {
			int c=pcsi.pCountCompany("Capgemini");
			System.out.println(c);
		} catch (RecruitmentException e) {
			
			e.printStackTrace();
		}
	}

}
