package com.cg.rms.service;

import java.util.ArrayList;

import com.cg.rms.beans.CandidatePersonal;

public interface CompanyService {
	
	public ArrayList <CandidatePersonal> SearchByCompany
	(String position,String experience,String qualification);

}
